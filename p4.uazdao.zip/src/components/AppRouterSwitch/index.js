export { AppRouterSwitch } from './AppRouterSwitch';
