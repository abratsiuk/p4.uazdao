export const menu = [
    { to: '/home', text: 'главная' },
    { to: '/sentence', text: 'изречение' },
    { to: '/author', text: 'Павел Иевлев' },
    { to: '/book-uazdao', text: 'версия 1' },
    { to: '/book-multiverse', text: 'версия 2' },
    { to: '/book-mizantrop', text: 'версия 3' },
];
