## for start in new note
```
    npm install --global yarn

    --admin:
    corepack enable
    corepack prepare yarn@4.5.3 --activate

    yarn config set nodeLinker node-modules
    yarn
    yarn dev
```